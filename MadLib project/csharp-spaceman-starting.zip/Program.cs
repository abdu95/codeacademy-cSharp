﻿using System;

namespace Spaceman
{
  class Program
  {
    static void Main(string[] args)
    {

    }
  }
}
